




# HermesClient
    * clean shutdown
    * support sequence (receiver should populate this)
    * support senderSequence
    * reconnects
        * track timeout
        * track last sequence
        * reconnect using last sequence